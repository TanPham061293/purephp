CKEDITOR.plugins.setLang('video', 'ru', {
  button: 'Видео',
  title: 'Параметры видео',
  emptySrc: 'Видео не выбрано!',
  controls: 'Элементы управления',
  mutedLoopingAutoplay: 'Автовоспроизведение без звука',
  preview: 'Предпросмотр',
  invalidSrc: 'Некорректный URL или видео не может быть воспроизведено'
});
