# video
A CKEditor plugin to insert HTML5 video
